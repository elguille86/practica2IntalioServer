INSERT INTO  pedido (cod_producto,nom_producto,total_pedido, fecha_pedido,estado_pedido,prioridad_pedido) VALUES (?,?,?,?,?,?)



  

  

